package com.warrioraspirants.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.io.*;
import java.net.*;
import android.database.Cursor;
import android.provider.OpenableColumns;
import org.json.*;

public class MainActivity extends Activity {
    // V10: bundled curriculum keeps core preparation available offline.

    LinearLayout content, nav;
    SharedPreferences sp;
    Handler handler = new Handler();
    long studySeconds;
    boolean running;
    static final int BG=Color.rgb(247,249,252), SURFACE=Color.WHITE, SURFACE2=Color.rgb(242,246,251), TEXT=Color.rgb(20,31,48),
        MUTED=Color.rgb(104,117,137), BLUE=Color.rgb(25,91,210), CYAN=Color.rgb(26,150,166), GREEN=Color.rgb(22,157,111),
        PURPLE=Color.rgb(105,79,190), ORANGE=Color.rgb(224,128,28), PINK=Color.rgb(218,72,112);
    final ArrayList<Topic> topics=new ArrayList<>();
    final ArrayList<Question> questions=new ArrayList<>(); final ArrayList<News> news=new ArrayList<>();
    final Runnable[] tickHolder=new Runnable[1];
    final Runnable tick = new Runnable(){ public void run(){ if(running){ studySeconds++; sp.edit().putLong("study",studySeconds).apply(); updateTimer(); handler.postDelayed(this,1000); } } };

    static class Topic { String subject,name,theory,concept,formula,trick,example,diagram,pyq,solution,revision,mistakes;
        Topic(String s,String n,String t,String c,String f,String k,String e,String d,String p,String sol,String rev,String mis){
            subject=s;name=n;theory=t;concept=c;formula=f;trick=k;example=e;diagram=d;pyq=p;solution=sol;revision=rev;mistakes=mis;
        }
    }
    static class Question { String subject,q,a,b,c,d,ans; Question(String s,String q,String a,String b,String c,String d,String ans){this.subject=s;this.q=q;this.a=a;this.b=b;this.c=c;this.d=d;this.ans=ans;} }

    @Override public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("warrioraspirants",0);studySeconds=sp.getLong("study",0);handleGoogleCallback();seedTopics();seedQuestions();loadBundledContent();shell();home();syncCloudContent();}

    void loadBundledContent(){
        try{
            InputStream in=getAssets().open("content.json"); BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8")); StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null) sb.append(line); br.close();
            JSONObject root=new JSONObject(sb.toString()); JSONArray ts=root.optJSONArray("topics");
            if(ts!=null){ topics.clear(); for(int i=0;i<ts.length();i++){ JSONObject x=ts.getJSONObject(i); topics.add(new Topic(x.optString("subject"),x.optString("name"),x.optString("theory"),x.optString("concept"),x.optString("formula"),x.optString("trick"),x.optString("example"),x.optString("diagram"),x.optString("pyq"),x.optString("solution"),x.optString("revision"),x.optString("mistakes"))); } }
            JSONArray qs=root.optJSONArray("questions"); if(qs!=null){ questions.clear(); for(int i=0;i<qs.length();i++){ JSONObject x=qs.getJSONObject(i); JSONArray o=x.optJSONArray("options"); String a=o!=null&&o.length()>0?o.optString(0):""; String b=o!=null&&o.length()>1?o.optString(1):""; String c=o!=null&&o.length()>2?o.optString(2):""; String d=o!=null&&o.length()>3?o.optString(3):""; questions.add(new Question(x.optString("subject"),x.optString("question"),a,b,c,d,x.optString("answer")+" — "+x.optString("solution"))); } }
        }catch(Exception ignored){}
    }

    void handleGoogleCallback(){
        Uri data=getIntent().getData();
        if(data!=null && "warrioraspirants".equals(data.getScheme()) && "google-callback".equals(data.getHost())){
            String status=data.getQueryParameter("status");
            String email=data.getQueryParameter("email");
            if("success".equals(status)){
                sp.edit().putBoolean("google_connected",true).putString("google_email",email==null?"Google account":email).apply();
                Toast.makeText(this,"Google connected ✓",Toast.LENGTH_LONG).show();
            }else Toast.makeText(this,"Google connection cancelled/failed",Toast.LENGTH_LONG).show();
        }
    }

    void connectGoogle(){
        String base=getString(com.warrioraspirants.app.R.string.content_api_url).trim();
        if(base.isEmpty() || base.startsWith("https://YOUR_")){ Toast.makeText(this,"Admin panel me API URL set karo",Toast.LENGTH_LONG).show(); return; }
        try{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(base+"/auth/google/start?app_redirect=warrioraspirants://google-callback"))); }catch(Exception e){ Toast.makeText(this,"Google sign-in open nahi hua",Toast.LENGTH_SHORT).show(); }
    }

    void googleCard(){
        LinearLayout g=card(SURFACE);
        g.addView(label("GOOGLE ACCOUNT"));
        boolean connected=sp.getBoolean("google_connected",false);
        String email=sp.getString("google_email","");
        TextView title=tv(connected?"Google connected ✓":"Connect your Google account",18); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); g.addView(title);
        g.addView(muted(connected?(email.isEmpty()?"Account connected":"Connected: "+email):"Use Google OAuth. Warrior Aspirants never asks for your Google password."));
        Button b=btn(connected?"Reconnect Google":"Connect with Google",BLUE); b.setOnClickListener(v->{press(v);connectGoogle();}); g.addView(b);
        if(connected){
            Button yt=btn("YouTube: Sync my channel & videos",PURPLE); yt.setOnClickListener(v->{press(v);syncGoogleEndpoint("/api/google/youtube/channel","YouTube channel synced ✓"); syncGoogleEndpoint("/api/google/youtube/videos","YouTube videos synced ✓");}); g.addView(yt);
            Button drive=btn("Google Drive: Sync study files",CYAN); drive.setOnClickListener(v->{press(v);syncGoogleEndpoint("/api/google/drive/files","Google Drive synced ✓");}); g.addView(drive);
            Button analytics=btn("YouTube Analytics: Last 28 days",GREEN); analytics.setOnClickListener(v->{press(v);syncGoogleEndpoint("/api/google/youtube/analytics","YouTube analytics synced ✓");}); g.addView(analytics);
        }
        add(g);
    }

    void syncGoogleEndpoint(String endpoint,String success){
        String base=getString(com.warrioraspirants.app.R.string.content_api_url).trim(); String token=sp.getString("google_token","");
        if(base.isEmpty()||base.startsWith("https://YOUR_")||token.isEmpty()){Toast.makeText(this,"Google connection/configuration complete nahi hai",Toast.LENGTH_LONG).show();return;}
        new Thread(()->{try{ HttpURLConnection c=(HttpURLConnection)new URL(base+endpoint+"?token="+URLEncoder.encode(token,"UTF-8")).openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(12000); if(c.getResponseCode()==200) runOnUiThread(()->Toast.makeText(this,success,Toast.LENGTH_SHORT).show()); else runOnUiThread(()->Toast.makeText(this,"Google sync failed",Toast.LENGTH_SHORT).show()); }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Google sync failed",Toast.LENGTH_SHORT).show());}}).start();
    }

    void syncCloudContent(){
        new Thread(()->{
            try{ String url=getString(com.warrioraspirants.app.R.string.content_api_url).trim(); if(url.isEmpty() || url.startsWith("https://YOUR_")) return;
                HttpURLConnection c=(HttpURLConnection)new URL(url+"/api/content").openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000); c.setRequestMethod("GET");
                if(c.getResponseCode()!=200)return; BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream())); StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null)sb.append(line); br.close();
                JSONObject root=new JSONObject(sb.toString()); JSONArray ts=root.optJSONArray("topics"); if(ts!=null){ topics.clear(); for(int i=0;i<ts.length();i++){JSONObject x=ts.getJSONObject(i); topics.add(new Topic(x.optString("subject"),x.optString("name"),x.optString("theory"),x.optString("concept"),x.optString("formula"),x.optString("trick"),x.optString("example"),x.optString("diagram"),x.optString("pyq"),x.optString("solution"),x.optString("revision"),x.optString("mistakes"))); } }
                JSONArray na=root.optJSONArray("currentAffairs"); if(na!=null){ news.clear(); for(int i=0;i<na.length();i++){JSONObject x=na.getJSONObject(i);news.add(new News(x.optString("title"),x.optString("link"),x.optString("publishedAt"),x.optString("source")));} }
                getSharedPreferences("warrioraspirants",0).edit().putInt("cloud_version",root.optInt("version",1)).apply(); runOnUiThread(()->{ if(content!=null) home(); Toast.makeText(this,"Cloud content updated ✓",Toast.LENGTH_SHORT).show(); });
            }catch(Exception ignored){}
        }).start();
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(z);return t;}
    TextView muted(String s){TextView t=tv(s,13);t.setTextColor(MUTED);return t;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp((int)r));return g;}
    GradientDrawable gradient(int start,int end,float r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{start,end});g.setCornerRadius(dp((int)r));return g;}
    GradientDrawable outline(int c,int line,float r){GradientDrawable g=bg(c,r);g.setStroke(dp(1),line);return g;}
    LinearLayout card(int c){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(14),dp(16),dp(14));l.setBackground(outline(c,Color.rgb(232,236,242),16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));l.setLayoutParams(p);return l;}
    Button btn(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(c==Color.TRANSPARENT?TEXT:Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(dp(44));b.setPadding(dp(12),0,dp(12),0);b.setBackground(c==Color.TRANSPARENT?bg(Color.TRANSPARENT,13):bg(c,13));return b;}
    void add(View v){content.addView(v);v.setAlpha(0f);v.setTranslationY(dp(8));v.animate().alpha(1).translationY(0).setDuration(260).start();}
    void press(View v){v.animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction(()->v.animate().scaleX(1).scaleY(1).setDuration(90).start()).start();}
    TextView label(String s){TextView t=tv(s.toUpperCase(Locale.US),10);t.setTextColor(BLUE);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}

    void shell(){
        getWindow().setStatusBarColor(Color.WHITE); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(20),dp(12),dp(20),dp(10));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv("Warrior Aspirants",21);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setTextColor(TEXT);brand.addView(a);
        TextView sub=muted("Learn • Practice • Achieve");sub.setTextSize(11);brand.addView(sub);
        TextView legacy=muted("AATHVIK");legacy.setTextSize(8);legacy.setTypeface(Typeface.DEFAULT,Typeface.BOLD);legacy.setAlpha(.55f);brand.addView(legacy);
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView ai=tv("F",15);ai.setGravity(Gravity.CENTER);ai.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ai.setTextColor(Color.WHITE);ai.setBackground(bg(PINK,40));head.addView(ai,new LinearLayout.LayoutParams(dp(38),dp(38)));
        ai.setOnClickListener(v->{press(v);fighter();}); root.addView(head);
        View line=new View(this);line.setBackgroundColor(Color.rgb(231,235,241));root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView sv=new ScrollView(this);sv.setClipToPadding(false);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(8),dp(18),dp(16));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);nav.setPadding(dp(8),dp(7),dp(8),dp(7));nav.setBackgroundColor(Color.WHITE);
        String[] ns={"⌂\nHome","▦\nStudy","◷\nFocus","✓\nTests","◌\nProgress"};
        for(String n:ns){Button x=btn(n,Color.TRANSPARENT);x.setTextSize(11);x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);x.setGravity(Gravity.CENTER);x.setLineSpacing(0,0.9f);nav.addView(x,new LinearLayout.LayoutParams(0,dp(62),1));x.setOnClickListener(v->{press(v);if(n.contains("Home"))home();else if(n.contains("Study"))subjects();else if(n.contains("Focus"))focus();else if(n.contains("Tests"))tests();else progress();});}
        root.addView(nav);setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void section(String a,String b){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView t=tv(a,19);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);r.addView(t,new LinearLayout.LayoutParams(0,-2,1));r.addView(muted(b));add(r);}
    void home(){clear();
        TextView h=tv("Good morning, Aspirant 👋",24);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);add(h);
        add(muted("Small steps every day lead to big results."));
        LinearLayout goal=card(SURFACE);goal.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout gr=new LinearLayout(this);gr.setGravity(Gravity.CENTER_VERTICAL);TextView gt=tv("Today's Goal",15);gt.setTypeface(Typeface.DEFAULT,Typeface.BOLD);gr.addView(gt,new LinearLayout.LayoutParams(0,-2,1));
        TextView streak=tv("🔥 "+Math.max(1,sp.getInt("streak",1))+" day streak",12);streak.setTextColor(ORANGE);streak.setTypeface(Typeface.DEFAULT,Typeface.BOLD);gr.addView(streak);goal.addView(gr);
        int done=0;for(Topic t:topics)if(sp.getBoolean("done_"+t.name,false))done++; int pct=topics.isEmpty()?0:done*100/topics.size();
        TextView g2=muted("Topics completed  •  "+done+" / "+topics.size());g2.setPadding(0,dp(7),0,dp(5));goal.addView(g2);
        ProgressBar gp=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);gp.setMax(100);gp.setProgress(pct);gp.setProgressTintList(ColorStateList.valueOf(GREEN));goal.addView(gp);add(goal);
        LinearLayout cont=card(Color.rgb(18,34,57));cont.setPadding(dp(17),dp(16),dp(17),dp(16));
        TextView cl=tv("CONTINUE LEARNING",10);cl.setTextColor(Color.rgb(170,195,226));cl.setTypeface(Typeface.DEFAULT,Typeface.BOLD);cont.addView(cl);
        String next=topics.isEmpty()?"Start your preparation":topics.get(Math.min(done,topics.size()-1)).name;
        TextView ct=tv(next,18);ct.setTextColor(Color.WHITE);ct.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ct.setPadding(0,dp(5),0,dp(2));cont.addView(ct);
        cont.addView(muted("Theory  •  Practice  •  PYQ"));Button cb=btn("OPEN LESSON  →",Color.rgb(34,82,140));cb.setTextColor(Color.WHITE);cb.setOnClickListener(v->{press(v);if(!topics.isEmpty())topic(topics.get(Math.min(done,topics.size()-1)));});cont.addView(cb);add(cont);
        section("Quick Access","Your essentials");
        LinearLayout r1=new LinearLayout(this);r1.setOrientation(LinearLayout.HORIZONTAL);r1.addView(tile("▦","Study",BLUE,()->subjects()),new LinearLayout.LayoutParams(0,dp(92),1));r1.addView(tile("✓","Practice",PURPLE,()->questions()),new LinearLayout.LayoutParams(0,dp(92),1));r1.addView(tile("♢","Tests",ORANGE,()->tests()),new LinearLayout.LayoutParams(0,dp(92),1));add(r1);
        LinearLayout r2=new LinearLayout(this);r2.setOrientation(LinearLayout.HORIZONTAL);r2.addView(tile("↻","Revision",GREEN,()->revision()),new LinearLayout.LayoutParams(0,dp(92),1));r2.addView(tile("F","FIGHTER AI",PINK,()->fighter()),new LinearLayout.LayoutParams(0,dp(92),1));r2.addView(tile("▥","PYQs",CYAN,()->pyqLibrary()),new LinearLayout.LayoutParams(0,dp(92),1));add(r2);
        section("Smart Tools","Built for your preparation");
        add(toolRow("📅","Daily Tasks","Plan today’s study target",()->tasks()));
        add(toolRow("❌","Mistake Book","Revise questions you got wrong",()->mistakes()));
        add(toolRow("📰","Current Affairs","Daily exam-focused updates",()->currentAffairs()));
        add(toolRow("📊","My Performance","Accuracy, progress & weak areas",()->progress()));
        add(toolRow("🗒","My Notes","Save your important points",()->notes()));
        add(toolRow("📄","PDF Library","Your study files in one place",()->pdfLibrary()));
    }
    LinearLayout toolRow(String icon,String title,String sub,Runnable go){LinearLayout c=card(SURFACE);c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);TextView i=tv(icon,20);i.setGravity(Gravity.CENTER);c.addView(i,new LinearLayout.LayoutParams(dp(40),dp(40)));LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);TextView t=tv(title,15);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);mid.addView(t);mid.addView(muted(sub));c.addView(mid,new LinearLayout.LayoutParams(0,-2,1));TextView ar=tv("›",24);ar.setTextColor(MUTED);c.addView(ar);c.setOnClickListener(v->{press(v);go.run();});return c;}
    LinearLayout tile(String icon,String text,int color,Runnable go){LinearLayout c=card(SURFACE);c.setGravity(Gravity.CENTER);c.setPadding(dp(4),dp(7),dp(4),dp(7));TextView i=tv(icon,22);i.setTextColor(color);i.setGravity(Gravity.CENTER);c.addView(i);TextView t=tv(text,12);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,dp(3),0,0);c.addView(t);c.setOnClickListener(v->{press(v);go.run();});return c;}

    void subjects(){clear();section("SSC CGL Subjects","Topic Library");add(muted("Theory • Tricks • Example • Video • Reference • completion tracking"));LinkedHashMap<String,ArrayList<Topic>> g=new LinkedHashMap<>();for(Topic t:topics)g.computeIfAbsent(t.subject,k->new ArrayList<>()).add(t);for(String s:g.keySet()){LinearLayout c=card(SURFACE);TextView sh=tv(s+"  •  "+g.get(s).size()+" topics",17);sh.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(sh);for(Topic t:g.get(s)){Button b=btn((sp.getBoolean("done_"+t.name,false)?"✓  ":"○  ")+t.name,Color.TRANSPARENT);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setBackground(outline(Color.TRANSPARENT,Color.rgb(31,57,90),14));b.setOnClickListener(v->{press(v);topic(t);});c.addView(b,new LinearLayout.LayoutParams(-1,dp(47)));}add(c);}}
    void topic(Topic t){
        clear(); section(t.name,t.subject);
        add(cardText("COMPLETE LEARNING MODULE • THEORY → CONCEPT → PRACTICE → PYQ → REVISION"));
        addTopicSection("📖 THEORY", t.theory);
        addTopicSection("💡 CONCEPT", t.concept);
        addTopicSection("📐 FORMULAS / RULES", t.formula);
        addTopicSection("🧠 SHORT TRICK / MEMORY TRICK", t.trick);
        addTopicSection("✏️ SOLVED EXAMPLE", t.example);
        addTopicSection("📊 FIGURE / VISUAL NOTE", t.diagram);
        addTopicSection("📜 PYQ", t.pyq);
        addTopicSection("✅ DETAILED SOLUTION", t.solution);
        addTopicSection("🔄 QUICK REVISION", t.revision);
        addTopicSection("❌ COMMON MISTAKES", t.mistakes);
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        Button done=btn(sp.getBoolean("done_"+t.name,false)?"✓ COMPLETED":"MARK COMPLETE",GREEN);
        done.setOnClickListener(v->{press(v);sp.edit().putBoolean("done_"+t.name,!sp.getBoolean("done_"+t.name,false)).apply();topic(t);});
        r.addView(done,new LinearLayout.LayoutParams(0,dp(50),1));
        Button rev=btn("ADD REVISION",PURPLE);
        rev.setOnClickListener(v->{press(v);sp.edit().putBoolean("rev_"+t.name,true).apply();Toast.makeText(this,"Added to revision ✓",Toast.LENGTH_SHORT).show();});
        r.addView(rev,new LinearLayout.LayoutParams(0,dp(50),1)); add(r);
        LinearLayout r2=new LinearLayout(this);r2.setOrientation(LinearLayout.HORIZONTAL);
        Button practice=btn("❓ PRACTICE",BLUE); practice.setOnClickListener(v->{press(v);tests();});
        r2.addView(practice,new LinearLayout.LayoutParams(0,dp(50),1));
        Button video=btn("▶ VIDEO",CYAN);video.setOnClickListener(v->{press(v);web("Video • "+t.name,"https://www.youtube.com/results?search_query="+Uri.encode("SSC CGL "+t.name+" Hindi lecture"));});
        r2.addView(video,new LinearLayout.LayoutParams(0,dp(50),1));add(r2);
    }
    void addTopicSection(String title,String text){
        if(text==null || text.trim().isEmpty()) return;
        LinearLayout c=card(SURFACE); c.addView(label(title)); TextView body=tv(text,15);
        body.setLineSpacing(dp(4),1.05f); body.setTextIsSelectable(true); body.setPadding(0,dp(7),0,0); c.addView(body); add(c);
    }
    void pyqLibrary(){
        clear(); section("PYQ Library","SSC CGL • 2023–2025 • VERIFIED FREE SOURCES");
        add(cardText("Warrior Aspirants PYQ HUB • 2023 + 2024 + 2025 ke verified papers, answer keys, detailed-solution pages aur topic-wise PYQ practice sources ek jagah. Core app free-first rahega."));
        add(cardText("Verified online coverage is much larger than the bundled sample database. Current sources expose thousands of recent questions and shift-wise papers; Warrior Aspirants therefore keeps source links rather than copying third-party copyrighted paper text into the APK."));
        add(cardText("YEAR-WISE: 2023 • 2024 • 2025   |   SUBJECT-WISE: Quant • Reasoning • English • General Awareness   |   PRACTICE: full paper • topic-wise • timed"));
        String[][] src={
            {"2025 • All listed SSC CGL papers / shifts","https://career.aglasem.com/ssc/ssc-cgl/previous-papers/2025"},
            {"2024 • All listed SSC CGL papers / shifts","https://career.aglasem.com/ssc/ssc-cgl/previous-papers/2024"},
            {"2023 • All listed SSC CGL papers / shifts","https://career.aglasem.com/ssc/ssc-cgl/previous-papers/2023"},
            {"2025 • Tier-I + Tier-II • Answer Key + Detailed Solutions","https://prepp.in/ssc-cgl-exam/question-paper-2025"},
            {"2024 • Tier-I + Tier-II • Answer Key + Detailed Solutions","https://prepp.in/ssc-cgl-exam/question-paper-2024"},
            {"2023 • Tier-I + Tier-II • Answer Key + Detailed Solutions","https://prepp.in/ssc-cgl-exam/question-paper-2023"},
            {"Topic-wise Mathematics PYQs","https://edurev.in/courses/60086_SSC-CGL-Previous-Year-Papers"},
            {"General Awareness • Topic-wise PYQs","https://edurev.in/ssc-cgl-exam/previous-year-papers/topic/general-awareness-previous-year-papers-topic-wise-84396"},
            {"Large SSC CGL PYQ archive • year/shift","https://sscprep.setuindustrial.com/pyq"},
            {"Free previous-year paper PDF index","https://docs.aglasem.com/org/ssc/ssc-cgl/question-paper"},
            {"Free PYQs + topic-weightage analysis","https://bharatmock.com/ssc-cgl-exam/previous-year-pdf"},
            {"PYQs + worked-solution practice","https://aitestplanet.com/tests/ssc-cgl"}
        };
        for(String[] x:src){
            LinearLayout c=card(SURFACE); c.addView(tv(x[0],16)); c.addView(muted("Verified source • opens in browser"));
            Button b=btn("OPEN SOURCE",BLUE); b.setOnClickListener(v->{press(v);web(x[0],x[1]);}); c.addView(b); add(c);
        }
        add(cardText("Warrior Aspirants TOPIC MAP: Quant • Reasoning • English • History • Geography • Polity • Economy • Science • Computer • Static GK. Source se question practice karne ke baad Warrior Aspirants topic module me theory, formula, trick, revision aur mistakes revise karo."));
        add(cardText("NOTE: Third-party copyrighted paper text ko bulk copy karke APK me redistribute nahi kiya gaya hai. Warrior Aspirants me verified source/solution links hain. Agar future me licensed/public-domain question datasets milte hain, unhe offline database me import kiya ja sakta hai."));
    }

    void currentAffairs(){
        clear(); section("Current Affairs","Internet-synced exam news");
        add(cardText("Latest content comes from your configured Warrior Aspirants server feeds. Verify important notices against official sources."));
        Button s=btn("↻ SYNC LATEST",CYAN);s.setOnClickListener(v->{press(v);syncCloudContent();currentAffairs();});add(s);
        if(news.isEmpty()){add(cardText("No live items yet. Configure NEWS_FEEDS on the server and refresh from Admin."));return;}
        for(News n:news){LinearLayout c=card(SURFACE);c.addView(tv(n.title,15));c.addView(muted(n.date+" • "+n.source));if(n.link!=null&&!n.link.isEmpty()){Button b=btn("OPEN SOURCE",BLUE);b.setOnClickListener(v->web("Source",n.link));c.addView(b);}add(c);}
    }

    void pdfLibrary(){
        clear(); section("PDF Library","Upload • study • AI-ready");
        add(cardText("Apni study PDF upload karo. Warrior Aspirants secure backend par PDF save karega aur future AI analysis ke liye available rakhega."));
        Button up=btn("📄 UPLOAD PDF",ORANGE); up.setOnClickListener(v->{press(v);Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/pdf");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,77);}); add(up);
        Button refresh=btn("↻ REFRESH LIBRARY",CYAN); refresh.setOnClickListener(v->{press(v);loadPdfList();}); add(refresh);
        loadPdfList();
    }
    void loadPdfList(){
        new Thread(()->{
            try{
                String base=getString(R.string.content_api_url).trim(); if(base.isEmpty()||base.startsWith("https://YOUR_")) return;
                HttpURLConnection c=(HttpURLConnection)new URL(base+"/api/pdfs").openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000);
                if(c.getResponseCode()!=200)return; BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();
                JSONArray arr=new JSONArray(sb.toString());
                runOnUiThread(()->{for(int i=0;i<arr.length();i++)try{JSONObject x=arr.getJSONObject(i);LinearLayout card=card(SURFACE);card.addView(tv("📄 "+x.optString("name"),15));card.addView(muted(x.optString("uploadedAt","")));Button open=btn("OPEN PDF",BLUE);String u=base+x.optString("url");open.setOnClickListener(v->{press(v);web(x.optString("name"),u);});card.addView(open);add(card);}catch(Exception ignored){}});
            }catch(Exception ignored){}
        }).start();
    }
    void uploadPdf(Uri uri){
        new Thread(()->{
            try{
                String base=getString(R.string.content_api_url).trim();if(base.isEmpty()||base.startsWith("https://YOUR_")){runOnUiThread(()->Toast.makeText(this,"First configure Warrior Aspirants server URL",Toast.LENGTH_LONG).show());return;}
                String boundary="----Warrior Aspirants"+System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(base+"/api/pdfs").openConnection();
                c.setDoOutput(true);c.setRequestMethod("POST");c.setConnectTimeout(10000);c.setReadTimeout(60000);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary); c.setRequestProperty("Authorization","Bearer "+getString(R.string.app_upload_token));
                OutputStream out=c.getOutputStream();String name="study.pdf";Cursor cur=getContentResolver().query(uri,null,null,null,null);if(cur!=null){int ni=cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(cur.moveToFirst()&&ni>=0)name=cur.getString(ni);cur.close();}
                out.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+name.replace("\"","_")+"\"\r\nContent-Type: application/pdf\r\n\r\n").getBytes("UTF-8"));
                InputStream in=getContentResolver().openInputStream(uri);byte[] buf=new byte[8192];int n;while(in!=null&&(n=in.read(buf))!=-1)out.write(buf,0,n);if(in!=null)in.close();
                out.write(("\\r\\n--"+boundary+"--\\r\\n").getBytes("UTF-8"));out.close();int code=c.getResponseCode();
                runOnUiThread(()->{Toast.makeText(this,code>=200&&code<300?"PDF uploaded ✓":"PDF upload failed ("+code+")",Toast.LENGTH_LONG).show();pdfLibrary();});
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"PDF upload failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();
    }

    void tasks(){clear();section("Daily Tasks","Consistency system");String[] ts={"30 min Quant practice","30 min Reasoning practice","30 min English practice","45 min GA revision","20 PYQ questions","Revise mistakes","1 mock / sectional test"};for(int i=0;i<ts.length;i++){final int k=i;LinearLayout c=card(SURFACE);CheckBox cb=new CheckBox(this);cb.setText(ts[i]);cb.setTextColor(TEXT);cb.setTextSize(14);cb.setChecked(sp.getBoolean("task_"+i,false));cb.setOnCheckedChangeListener((b,v)->sp.edit().putBoolean("task_"+k,v).apply());c.addView(cb);add(c);}add(muted("Daily completion: "+taskCount()+" / "+ts.length));}
    int taskCount(){int n=0;for(int i=0;i<7;i++)if(sp.getBoolean("task_"+i,false))n++;return n;}
    void revision(){clear();section("Revision Planner","Spaced revision");add(muted("Topics marked for revision appear here. Complete them again from Subjects."));boolean any=false;for(Topic t:topics)if(sp.getBoolean("rev_"+t.name,false)){any=true;LinearLayout c=card(SURFACE);c.addView(tv(t.name,15));Button b=btn("MARK REVISED",GREEN);b.setOnClickListener(v->{press(v);sp.edit().remove("rev_"+t.name).apply();revision();});c.addView(b);add(c);}if(!any)add(cardText("No revision topics yet. Open a topic → ADD REVISION."));}
    void mistakes(){clear();section("Mistake Book","Learn from errors");LinearLayout addc=card(SURFACE2);EditText e=new EditText(this);e.setHint("Mistake / question / concept...");e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setMinLines(3);addc.addView(e);Button save=btn("SAVE MISTAKE",PINK);save.setOnClickListener(v->{String s=e.getText().toString().trim();if(!s.isEmpty()){int n=sp.getInt("mistakes",0);sp.edit().putString("mistake_"+n,s).putInt("mistakes",n+1).apply();mistakes();}});addc.addView(save);add(addc);int n=sp.getInt("mistakes",0);if(n==0)add(cardText("No mistakes saved yet."));for(int i=n-1;i>=0;i--){final int k=i;LinearLayout c=card(SURFACE);c.addView(tv("#"+(i+1)+"  "+sp.getString("mistake_"+i,""),14));Button d=btn("DELETE",Color.rgb(35,48,67));d.setOnClickListener(v->{sp.edit().remove("mistake_"+k).apply();Toast.makeText(this,"Deleted",Toast.LENGTH_SHORT).show();mistakes();});c.addView(d);add(c);}}
    void notes(){clear();section("My Notes","Quick notes");add(muted("Jo bhi important point, idea ya reminder ho, yahan save kar sakte ho."));
        LinearLayout editor=card(SURFACE2);
        EditText e=new EditText(this);e.setHint("Yahan apna note likho...");e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setTextSize(16);e.setGravity(Gravity.TOP|Gravity.START);e.setMinLines(5);e.setPadding(dp(12),dp(12),dp(12),dp(12));e.setBackground(outline(Color.rgb(18,35,58),Color.rgb(54,211,229),16));editor.addView(e);
        Button save=btn("SAVE NOTE",CYAN);save.setOnClickListener(v->{press(v);String s=e.getText().toString().trim();if(!s.isEmpty()){int n=sp.getInt("notes",0);sp.edit().putString("note_"+n,s).putInt("notes",n+1).apply();notes();Toast.makeText(this,"Note saved ✓",Toast.LENGTH_SHORT).show();}});editor.addView(save);add(editor);
        int n=sp.getInt("notes",0);if(n==0){add(cardText("No notes yet. Write something above and save it."));return;}
        for(int i=n-1;i>=0;i--){final int k=i;LinearLayout c=card(SURFACE);c.addView(label("NOTE "+(i+1)));TextView body=tv(sp.getString("note_"+i,""),15);body.setTextIsSelectable(true);body.setPadding(0,dp(6),0,dp(8));c.addView(body);Button d=btn("DELETE",Color.rgb(35,48,67));d.setOnClickListener(v->{sp.edit().remove("note_"+k).apply();notes();});c.addView(d);add(c);}
    }
    void questions(){
        clear(); section("Question Bank","Practice • Filter • Learn");
        add(muted(questions.size()+" questions loaded • instant answer • mistake tracking • 100% free/offline"));
        Spinner filter=new Spinner(this); ArrayList<String> fs=new ArrayList<>(); fs.add("All Subjects"); LinkedHashSet<String> subs=new LinkedHashSet<>(); for(Question q:questions)subs.add(q.subject); fs.addAll(subs);
        ArrayAdapter<String> fa=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,fs); filter.setAdapter(fa); add(filter);
        EditText search=new EditText(this); search.setHint("Search question / subject..."); search.setHintTextColor(MUTED); search.setTextColor(TEXT); add(search);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); add(list);
        Runnable render=()->{ list.removeAllViews(); String f=String.valueOf(filter.getSelectedItem()); String needle=search.getText().toString().trim().toLowerCase(Locale.US); int shown=0;
            for(int i=0;i<questions.size();i++){ Question q=questions.get(i); if(!f.equals("All Subjects")&&!q.subject.equals(f))continue; if(!needle.isEmpty()&&!((q.q+" "+q.subject).toLowerCase(Locale.US).contains(needle)))continue; shown++;
                LinearLayout c=card(SURFACE); c.addView(label(q.subject)); c.addView(tv("Q"+shown+"  "+q.q,15));
                String[] opts={q.a,q.b,q.c,q.d}; RadioGroup rg=new RadioGroup(this); for(int j=0;j<4;j++){RadioButton rb=new RadioButton(this);rb.setText((char)('A'+j)+". "+opts[j]);rb.setTextColor(TEXT);rg.addView(rb);} c.addView(rg);
                Button check=btn("CHECK ANSWER",PURPLE); TextView result=muted(""); check.setOnClickListener(v->{press(v);int id=rg.getCheckedRadioButtonId(); if(id==-1){result.setText("Select an option first.");return;} int pos=rg.indexOfChild(rg.findViewById(id)); int correct=answerIndex(q.ans); boolean ok=pos==correct; result.setText(ok?"✓ Correct! +2 marks":"✗ Incorrect. Correct answer: "+(char)('A'+correct)+" • "+q.ans); result.setTextColor(ok?GREEN:PINK); if(!ok) saveAutoMistake(q); sp.edit().putInt("practice_attempts",sp.getInt("practice_attempts",0)+1).apply(); }); c.addView(check); c.addView(result); list.addView(c); }
            if(shown==0)list.addView(cardText("No questions match this filter.")); };
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();} public void onNothingSelected(android.widget.AdapterView<?> p){}});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){render.run();} public void afterTextChanged(android.text.Editable e){}});
        render.run();
    }
    int answerIndex(String ans){ if(ans==null||ans.isEmpty())return 0; char ch=Character.toUpperCase(ans.trim().charAt(0)); return ch>='A'&&ch<='D'?ch-'A':0; }
    void saveAutoMistake(Question q){ int n=sp.getInt("mistakes",0); sp.edit().putString("mistake_"+n,"[Practice] "+q.q+" | Correct: "+q.ans).putInt("mistakes",n+1).apply(); }

    void tests(){
        clear(); section("Mock Tests","Real practice engine");
        add(cardText("Free mock engine • +2 correct • −0.50 wrong • 0 unattempted • timer • instant analysis"));
        String[] modes={"SSC CGL Mixed","Quantitative Aptitude","Reasoning","English Language","General Awareness — History","General Awareness — Geography","General Awareness — Polity","General Awareness — Economy","General Awareness — Science","Computer","Static GK"};
        for(String mode:modes){Button b=btn("▶ START "+mode, mode.contains("Mixed")?PURPLE:BLUE); b.setOnClickListener(v->{press(v);startMock(mode);}); add(b);}
        LinearLayout hist=card(SURFACE); hist.addView(label("MOCK HISTORY")); int mc=sp.getInt("mock_count",0); hist.addView(muted("Attempts: "+mc+" • Best score: "+String.format(Locale.US,"%.2f",sp.getFloat("best_score",0)))); Button clear=btn("RESET MOCK HISTORY",Color.rgb(35,48,67)); clear.setOnClickListener(v->{sp.edit().remove("mock_count").remove("best_score").remove("last_score").apply();tests();}); hist.addView(clear); add(hist);
    }
    void startMock(String mode){
        ArrayList<Question> pool=new ArrayList<>(); for(Question q:questions)if(mode.startsWith("SSC")||q.subject.equals(mode))pool.add(q);
        if(pool.isEmpty()){Toast.makeText(this,"Is subject ke questions abhi available nahi hain. Sync/update content karo.",Toast.LENGTH_LONG).show();return;}
        Collections.shuffle(pool,new Random()); int count=Math.min(mode.startsWith("SSC")?Math.min(20,pool.size()):Math.min(10,pool.size()),pool.size()); final ArrayList<Question> quiz=new ArrayList<>(pool.subList(0,count));
        final int[] idx={0,0,0}; final float[] score={0f}; final long end=System.currentTimeMillis()+count*60000L;
        showMockQuestion(mode,quiz,idx,score,end);
    }
    void showMockQuestion(String mode,ArrayList<Question> quiz,int[] idx,float[] score,long end){
        clear(); Question q=quiz.get(idx[0]); section("Mock "+(idx[0]+1)+" / "+quiz.size(),mode);
        TextView timer=tv("Time left: "+mockTime(end),15); timer.setTextColor(ORANGE); add(timer);
        LinearLayout c=card(SURFACE); c.addView(tv(q.q,17)); RadioGroup rg=new RadioGroup(this); String[] o={q.a,q.b,q.c,q.d}; for(int i=0;i<4;i++){RadioButton rb=new RadioButton(this);rb.setText((char)('A'+i)+". "+o[i]);rb.setTextColor(TEXT);rg.addView(rb);} c.addView(rg);
        Button next=btn(idx[0]==quiz.size()-1?"FINISH MOCK":"NEXT QUESTION",GREEN); next.setOnClickListener(v->{int chosen=rg.getCheckedRadioButtonId(); if(chosen==-1){score[0]+=0; idx[1]++;}else{int pos=rg.indexOfChild(rg.findViewById(chosen)); if(pos==answerIndex(q.ans))score[0]+=2;else{score[0]-=.5f;saveAutoMistake(q);idx[2]++;}} idx[0]++; if(idx[0]>=quiz.size()||System.currentTimeMillis()>end){finishMock(mode,quiz,score[0],idx[2]);}else showMockQuestion(mode,quiz,idx,score,end);}); c.addView(next); add(c);
        handler.postDelayed(new Runnable(){public void run(){if(content!=null&&idx[0]<quiz.size()&&System.currentTimeMillis()>=end)finishMock(mode,quiz,score[0],idx[2]); else if(content!=null&&idx[0]<quiz.size()){View v=findTag(content,"mocktimer");if(v!=null)((TextView)v).setText("Time left: "+mockTime(end));handler.postDelayed(this,1000);}}},1000); timer.setTag("mocktimer");
    }
    String mockTime(long end){long sec=Math.max(0,(end-System.currentTimeMillis())/1000);return String.format(Locale.US,"Time left: %02d:%02d",sec/60,sec%60);}
    void finishMock(String mode,ArrayList<Question> quiz,float score,int wrong){int attempts=sp.getInt("mock_count",0)+1;float best=Math.max(score,sp.getFloat("best_score",-999));sp.edit().putInt("mock_count",attempts).putFloat("last_score",score).putFloat("best_score",best).apply(); clear(); section("Mock Result","Performance analysis"); TextView big=tv(String.format(Locale.US,"%.2f / %.2f",score,quiz.size()*2f),38);big.setGravity(Gravity.CENTER);big.setTypeface(Typeface.DEFAULT,Typeface.BOLD);add(big);add(cardText("Mode: "+mode+"
Questions: "+quiz.size()+"
Wrong: "+wrong+"
Best score: "+String.format(Locale.US,"%.2f",best))); Button again=btn("RETAKE MOCK",PURPLE);again.setOnClickListener(v->{press(v);startMock(mode);});add(again);Button back=btn("BACK TO TESTS",BLUE);back.setOnClickListener(v->{press(v);tests();});add(back);}
    void progress(){clear();section("My Progress","Analytics + Weak Areas");int done=0;for(Topic t:topics)if(sp.getBoolean("done_"+t.name,false))done++;int pct=topics.isEmpty()?0:done*100/topics.size();LinearLayout c=card(SURFACE2);TextView p=tv(pct+"%",44);p.setGravity(Gravity.CENTER);p.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(p);TextView z=tv(done+" / "+topics.size()+" topics completed",14);z.setGravity(Gravity.CENTER);z.setTextColor(CYAN);c.addView(z);ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(pct);pb.setProgressTintList(ColorStateList.valueOf(GREEN));c.addView(pb);add(c);add(cardText("⏱ Focus time: "+format(studySeconds)));add(cardText("📅 Daily tasks: "+taskCount()+" / 7"));add(cardText("📝 Mocks: "+sp.getInt("mock_count",0)+" • Best: "+String.format(Locale.US,"%.2f",sp.getFloat("best_score",0))));add(cardText("❌ Mistakes saved: "+sp.getInt("mistakes",0)));add(cardText("❓ Practice attempts: "+sp.getInt("practice_attempts",0)));
        int pending=topics.size()-done; add(cardText("🎯 Next target: "+pending+" topics remaining"));
        LinkedHashMap<String,Integer> subDone=new LinkedHashMap<>(); for(Topic t:topics){int v=subDone.containsKey(t.subject)?subDone.get(t.subject):0; if(sp.getBoolean("done_"+t.name,false))subDone.put(t.subject,v+1); else subDone.put(t.subject,v);}
        for(String sub:subDone.keySet()){int total=0,d=0;for(Topic t:topics)if(t.subject.equals(sub)){total++;if(sp.getBoolean("done_"+t.name,false))d++;}add(cardText("📚 "+sub+"
"+d+" / "+total+" complete • "+(total==0?0:d*100/total)+"%"));}
    }
    void focus(){clear();section("Focus Timer","Deep work");LinearLayout c=card(SURFACE2);TextView t=tv(format(studySeconds),46);t.setGravity(Gravity.CENTER);t.setTag("timer");t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(t);c.addView(muted("Every focused minute counts."));Button s=btn(running?"PAUSE FOCUS":"START FOCUS",BLUE);s.setOnClickListener(v->{running=!running;if(running)handler.post(tick);s.setText(running?"PAUSE FOCUS":"RESUME FOCUS");});c.addView(s);Button r=btn("RESET TIMER",Color.rgb(35,48,67));r.setOnClickListener(v->{running=false;studySeconds=0;sp.edit().putLong("study",0).apply();updateTimer();});c.addView(r);add(c);}
    void updateTimer(){View v=findTag(content,"timer");if(v!=null)((TextView)v).setText(format(studySeconds));}
    View findTag(ViewGroup g,String tag){for(int i=0;i<g.getChildCount();i++){View v=g.getChildAt(i);if(tag.equals(v.getTag()))return v;if(v instanceof ViewGroup){View x=findTag((ViewGroup)v,tag);if(x!=null)return x;}}return null;}
    void fighter(){clear();section("FIGHTER","AI Doubt Solver");add(muted("Live AI • SSC CGL focused • simple Hindi/Hinglish explanations"));LinearLayout c=card(SURFACE2);EditText q=new EditText(this);q.setHint("Apna doubt likho...\nExample: 20% increase ke baad 20% decrease hua, net change?");q.setHintTextColor(MUTED);q.setTextColor(TEXT);q.setMinLines(5);q.setGravity(Gravity.TOP);c.addView(q);Button ask=btn("🥊 ASK FIGHTER",PINK);ask.setOnClickListener(v->{press(v);String x=q.getText().toString().trim();if(x.isEmpty()){Toast.makeText(this,"Pehle doubt likho",Toast.LENGTH_SHORT).show();return;}ask.setEnabled(false);ask.setText("FIGHTER IS THINKING…");new Thread(()->{String answer=callFighter(x);runOnUiThread(()->{ask.setEnabled(true);ask.setText("🥊 ASK FIGHTER");if(answer==null||answer.isEmpty()){new AlertDialog.Builder(this).setTitle("FIGHTER").setMessage("Live AI connect nahi hua.\n\nServer URL aur OPENAI_API_KEY check karo.").setPositiveButton("OK",null).show();}else showFighterAnswer(answer);});}).start();});c.addView(ask);Button img=btn("🖼 ADD QUESTION IMAGE",Color.rgb(35,48,67));img.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,42);});c.addView(img);add(c);}
    String callFighter(String question){try{String base=getString(R.string.content_api_url).trim();if(base.isEmpty()||base.startsWith("https://YOUR_"))return null;HttpURLConnection c=(HttpURLConnection)new URL(base+"/api/fighter").openConnection();c.setConnectTimeout(12000);c.setReadTimeout(30000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");JSONObject body=new JSONObject();body.put("question",question);OutputStream os=c.getOutputStream();os.write(body.toString().getBytes("UTF-8"));os.close();int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();BufferedReader br=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();if(code!=200)return null;return new JSONObject(sb.toString()).optString("answer","");}catch(Exception e){return null;}}
    String offlineFighter(String q){
        String x=q==null?"":q.trim().toLowerCase(Locale.US);
        if(x.contains("percentage")||x.contains("प्रतिशत")) return "Offline FIGHTER\n\nPercentage = (Part / Whole) × 100\n\nShortcut: x% of y = y% of x.\nExample: 20% of 250 = 50.\n\nPractice: 15% of 400 = ?";
        if(x.contains("profit")||x.contains("loss")||x.contains("लाभ")||x.contains("हानि")) return "Offline FIGHTER\n\nProfit = SP − CP\nLoss = CP − SP\nProfit% = Profit/CP × 100\nLoss% = Loss/CP × 100\n\nExample: CP ₹500, SP ₹600 → Profit ₹100 = 20%.";
        if(x.contains("average")||x.contains("औसत")) return "Offline FIGHTER\n\nAverage = Total ÷ Number of observations\nTotal = Average × Number\n\nExample: 10, 20, 30 → average = 60/3 = 20.";
        if(x.contains("speed")||x.contains("distance")||x.contains("गति")||x.contains("दूरी")) return "Offline FIGHTER\n\nSpeed = Distance ÷ Time\nDistance = Speed × Time\nTime = Distance ÷ Speed\n\n1 km/h = 5/18 m/s.";
        if(x.contains("hcf")||x.contains("lcm")||x.contains("महत्तम")||x.contains("लघुत्तम")) return "Offline FIGHTER\n\nHCF: common factors ka greatest value.\nLCM: common multiples ka least value.\nPrime factorisation se dono quickly nikalo.";
        if(x.contains("sin")||x.contains("cos")||x.contains("tan")||x.contains("त्रिकोणमिति")) return "Offline FIGHTER\n\nSOH-CAH-TOA\nsin θ = Perpendicular/Hypotenuse\ncos θ = Base/Hypotenuse\ntan θ = Perpendicular/Base\n\nsin 30° = 1/2, cos 60° = 1/2.";
        return "Offline FIGHTER\n\nIs device par AI server configured nahi hai, lekin Warrior Aspirants offline study mode active hai.\n\nQuestion ko apne Subject/Topic me search karo; wahan Theory, Concept, Formula, Trick, Example, PYQ, Solution aur Revision material available hai.\n\nInternet available hone par optional AI server se detailed answer bhi mil sakta hai.";
    }
    void showFighterAnswer(String answer){ScrollView sv=new ScrollView(this);TextView t=tv(answer,15);t.setTextIsSelectable(true);t.setPadding(dp(4),dp(4),dp(4),dp(4));sv.addView(t);new AlertDialog.Builder(this).setTitle("🥊 FIGHTER ANSWER").setView(sv).setPositiveButton("OK",null).show();}
    @Override protected void onActivityResult(int r,int code,Intent data){super.onActivityResult(r,code,data);if(r==42&&code==RESULT_OK&&data!=null)Toast.makeText(this,"Image added to FIGHTER workflow ✓",Toast.LENGTH_SHORT).show(); if(r==77&&code==RESULT_OK&&data!=null)uploadPdf(data.getData());}
    void references(){clear();section("References","Trusted resources");String[] names={"SSC Official","NCERT","RBI","PIB","Current Affairs"};String[] urls={"https://ssc.gov.in/","https://ncert.nic.in/","https://www.rbi.org.in/","https://pib.gov.in/","https://www.google.com/search?q=SSC+CGL+current+affairs"};for(int i=0;i<names.length;i++){final String n=names[i],u=urls[i];Button b=btn("↗ "+n,CYAN);b.setOnClickListener(v->{press(v);web(n,u);});add(b);}}
    void web(String title,String url){WebView w=new WebView(this);w.setBackgroundColor(BG);w.setWebViewClient(new WebViewClient());WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setBuiltInZoomControls(false);new AlertDialog.Builder(this).setTitle(title).setView(w).setPositiveButton("CLOSE",(d,x)->w.destroy()).show();w.loadUrl(url);}
    LinearLayout cardText(String s){LinearLayout c=card(SURFACE);c.addView(muted(s));return c;}
    String format(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}

    void seedTopics(){
        add("Quantitative Aptitude","Number System","Natural, whole, integer, rational and irrational numbers; divisibility, factors, multiples, HCF/LCM and remainders are core areas.","Use prime factorisation for HCF/LCM and write remainder conditions explicitly.","HCF(12,18)=6; LCM(12,18)=36.");
        add("Quantitative Aptitude","Percentage","Percentage means per hundred. Revise conversions, comparison and successive increase/decrease.","x% of y = y% of x; successive changes use multiplication of factors.","20% up then 10% down = 1.2×0.9 = +8%.");
        add("Quantitative Aptitude","Profit & Loss","Profit = SP−CP and Loss = CP−SP. Revise profit/loss percentage, discount and marked price.","Profit p% → SP=CP(1+p/100).","CP ₹500, profit 20% → SP ₹600.");
        add("Quantitative Aptitude","Ratio & Proportion","Ratios compare quantities in the same units; proportion equates ratios. Revise direct/inverse proportion and partnership.","Convert units first, then simplify.","2:3 = 8:12.");
        add("Quantitative Aptitude","Average","Average = total ÷ number. Revise combined average and replacement questions.","Total = average × number.","Average of 10,20,30 = 20.");
        add("Quantitative Aptitude","Time & Work","Work is handled through rates. If A finishes in x days, one-day work is 1/x; combined rates add.","LCM of days often makes total work simple.","10-day + 15-day workers together finish in 6 days.");
        add("Quantitative Aptitude","SI & CI","Simple interest uses principal; compound interest adds interest to the amount periodically.","For 2 years, CI−SI=P(r/100)^2.","₹1000 at 10% for 2 years: SI ₹200, CI ₹210.");
        add("Quantitative Aptitude","Time Speed Distance","Speed = distance/time. km/h→m/s multiply 5/18. Revise relative speed and trains.","Equal-distance average speed = 2ab/(a+b).","60 km/h for 2 hours = 120 km.");
        add("Quantitative Aptitude","Algebra","Revise identities, linear equations, factorisation and quadratic basics.","Memorise (a+b)^2, (a−b)^2 and a²−b².","(x+5)(x−5)=x²−25.");
        add("Quantitative Aptitude","Geometry","Study lines, angles, triangles, quadrilaterals and circles; focus on properties and theorems.","Draw the figure before applying a theorem.","Angles of a triangle sum to 180°.");
        add("Quantitative Aptitude","Mensuration","Revise perimeter, area and volume of common shapes with unit conversion.","Write the required unit beside the formula.","Circle area = πr².");
        add("Quantitative Aptitude","Trigonometry","Learn basic ratios, standard angles, identities and heights/distances.","SOH-CAH-TOA for right triangles.","sin 30° = 1/2.");
        add("Reasoning","Analogy","Find the exact relationship in the first pair and apply it to the second.","Turn the first pair into a sentence.","Book:Read :: Food:Eat.");
        add("Reasoning","Series","Check differences, ratios, alternating terms and alphabet positions.","Start with first differences; then check second differences.","2,5,10,17 → next 26.");
        add("Reasoning","Coding Decoding","Use alphabet positions and compare character-wise transformations.","Write A=1 to Z=26 for difficult codes.","CAT shifted +1 becomes DBU.");
        add("Reasoning","Blood Relation","Convert statements into a small family tree and track gender/generation.","Draw instead of solving mentally.","Mother's brother = maternal uncle.");
        add("Reasoning","Direction Sense","Fix North at top and track turns; distinguish final direction from distance.","Use a simple compass sketch.","Facing North, right turn = East.");
        add("Reasoning","Syllogism","Statements define sets; conclusions must follow necessarily.","Use Venn diagrams and never assume extra information.","All A are B means A is a subset of B.");
        add("Reasoning","Venn Diagram","Represent set relationships, overlaps and classifications visually.","Translate both, only, neither and at least into regions.","Cricket + football players go in the overlap.");
        add("Reasoning","Seating Arrangement","Arrange people using fixed clues first, then relative clues; track perspective.","Place the most constrained pair first.","If A is immediately left of B, keep AB together initially.");
        add("English Language","Parts of Speech","Noun, pronoun, adjective, verb, adverb, preposition, conjunction and interjection describe word functions.","Ask what the word is doing in the sentence.","Quickly is usually an adverb.");
        add("English Language","Tenses","Revise present, past and future in simple, continuous, perfect and perfect continuous forms.","Learn helping-verb patterns with time markers.","She has finished = present perfect.");
        add("English Language","Articles","A/an are indefinite; the is definite. Choice depends on sound and specificity.","an hour but a university.","He is an honest man.");
        add("English Language","Prepositions","Prepositions show time, place, direction and relationships; revise common fixed combinations.","Learn high-frequency phrases together.","She is good at English.");
        add("English Language","Subject Verb Agreement","The verb agrees with the true grammatical subject, not the nearest noun.","Remove interrupting phrases and find the subject.","The list of items is on the table.");
        add("English Language","Active Passive Voice","Active highlights the doer; passive highlights the receiver while preserving tense.","Object of active sentence becomes passive subject.","They write a letter → A letter is written by them.");
        add("English Language","Direct Indirect Speech","Reported speech changes pronouns, tense and time expressions according to context.","Identify statement/question/command first.","He said, I am tired → He said that he was tired.");
        add("English Language","Error Detection","Scan agreement, tense, articles, prepositions, modifiers, pronouns and parallelism.","Use the same scan order every time.","She do not know → She does not know.");
        add("English Language","Vocabulary & Idioms","Build synonyms, antonyms, one-word substitutions, roots and common idioms with spaced revision.","Keep confusing words in pairs.","Break the ice = start a conversation.");
        add("General Awareness — History","Ancient India","Indus Valley, Vedic period, Mahajanapadas, Buddhism, Jainism, Mauryas, Guptas and culture.","Use a one-page chronology.","Ashoka is associated with the Mauryan Empire.");
        add("General Awareness — History","Medieval India","Delhi Sultanate, Mughals, Bhakti-Sufi traditions, Vijayanagara and Marathas.","Founder → Capital → Major ruler → feature.","Akbar is a major Mughal ruler.");
        add("General Awareness — History","Modern India","European expansion, British rule, 1857, INC, national movements and independence.","Cause → Leader → Year → Method → Outcome.","Non-Cooperation began in 1920.");
        add("General Awareness — Geography","Physical Geography","Earth interior, rocks, plate tectonics, mountains, rivers, atmosphere, climate and oceans.","Draw diagrams for layers and pressure belts.","Weather is short-term; climate is long-term.");
        add("General Awareness — Geography","Indian Geography","Physiography, rivers, soils, monsoon, agriculture, minerals, industries and maps.","Use map-based revision.","Black soil is strongly associated with cotton regions.");
        add("General Awareness — Polity","Constitution Basics","Study Preamble, Fundamental Rights, DPSP, Duties and Union/State structure.","Map Legislature → Executive → Judiciary.","Fundamental Rights are mainly in Part III.");
        add("General Awareness — Polity","Parliament & President","Study Houses, law-making, money bills, committees and executive accountability.","Compare Lok Sabha and Rajya Sabha in a table.","Money Bills have a special Lok Sabha role.");
        add("General Awareness — Polity","Judiciary & Bodies","Study courts, judicial review, writs, Election Commission, CAG, UPSC and Finance Commission.","Source → appointment → tenure → function.","Habeas corpus concerns unlawful detention.");
        add("General Awareness — Economy","Basic Economics","Demand, supply, GDP, inflation, real vs nominal values and basic economic concepts.","Separate stock vs flow and real vs nominal.","Inflation is a sustained rise in general price level.");
        add("General Awareness — Economy","Banking & Monetary Policy","RBI, banks, deposits, loans, repo, reverse repo, CRR and SLR.","Make an RBI-tool → liquidity-effect sheet.","Higher CRR generally reduces lendable funds.");
        add("General Awareness — Economy","Budget & Fiscal Policy","Revenue, expenditure, borrowing, direct/indirect taxes and fiscal deficit.","Fiscal = government budget; monetary = money/credit.","Fiscal deficit reflects a financing gap.");
        add("General Awareness — Science","Physics Basics","Units, motion, force, work, energy, power, heat, sound, light, electricity and magnetism.","Pair every formula with SI unit + example.","Power = work/time; watt is SI unit.");
        add("General Awareness — Science","Chemistry Basics","Matter, atoms, periodic trends, reactions, acids/bases/salts, metals and carbon compounds.","Learn reaction as reactants → products + use.","Acid + base generally gives salt + water.");
        add("General Awareness — Science","Biology Basics","Cell, tissues, human systems, nutrition, diseases, genetics, plants, ecology and evolution.","Organ → function → hormone/enzyme → disorder.","Hemoglobin carries oxygen in RBCs.");
        add("General Awareness — Science","Environment & Ecology","Ecosystems, food chains, biodiversity, pollution, climate change and conservation.","Draw producers → consumers → decomposers.","Energy decreases across trophic levels.");
        add("General Awareness — Static GK","Art Culture & Misc","Classical dances, festivals, monuments, books/authors, awards, sports terms and important days.","Use theme-based flashcards.","Learn each dance with region + feature.");
        add("General Awareness — Computer","Computer Fundamentals","Hardware, software, CPU, memory, storage, OS, networks, internet, cybersecurity and shortcuts.","Memorise common shortcut pairs.","Ctrl+C copies; Ctrl+V pastes.");
    }
    void add(String s,String n,String t,String k,String e){
        topics.add(new Topic(s,n,t,t,k,k,e,"Visualize the core idea with a simple number line/table/diagram where useful.","Add a relevant SSC/Railway/UP SI PYQ here.","Use the concept step-by-step; verify units and signs before the final answer.","Revise definition → formula/rule → one example → one PYQ.","Avoid memorising without understanding; check common traps and units."));
    }
    void seedQuestions(){questions.add(new Question("Quant","If CP is ₹500 and profit is 20%, SP is?","₹550","₹600","₹620","₹700","B — ₹600"));questions.add(new Question("Reasoning","2, 5, 10, 17, ?","24","25","26","27","C — 26"));questions.add(new Question("English","Choose the correct form: He ___ to school every day.","go","goes","going","gone","B — goes"));questions.add(new Question("Polity","Fundamental Rights are mainly in which Part?","II","III","IV","V","B — Part III"));questions.add(new Question("Science","SI unit of power is?","Joule","Newton","Watt","Pascal","C — Watt"));}
}
